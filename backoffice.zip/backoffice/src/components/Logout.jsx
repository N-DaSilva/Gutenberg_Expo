export const LogoutButton = () => {
    const handleLogout = () => {
        fetch('http://localhost/github/Gutenberg_Expo/backoffice/logout.php', {
            method: 'POST',
            credentials: 'include',
          }).then(() => window.location.href = 'http://localhost/github/Gutenberg_Expo/backoffice/connect.php')
            .catch((error) => console.error('Logout failed:', error))
    }

    return (
        <button onClick={handleLogout}>
            Se déconnecter
        </button>
    )
}